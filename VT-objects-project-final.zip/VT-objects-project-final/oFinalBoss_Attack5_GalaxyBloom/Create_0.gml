box = instance_find(oBattleBox, 0);

center_x = box.x;
center_y = box.y;

shoot_timer = 0;
shoot_delay = 23;

ring_angle = 0;




rotation_speed = 1.6;
rotation_dir = 1;

direction_timer = room_speed * 2;