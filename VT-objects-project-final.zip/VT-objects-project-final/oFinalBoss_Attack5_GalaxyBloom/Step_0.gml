shoot_timer -= 1;
direction_timer -= 1;

//change à un moment (aléatoirement) la rotation
if (direction_timer <= 0)
{
    rotation_dir = choose(-1, 1);
    rotation_speed = random_range(1.0, 2.2);

    direction_timer = random_range(room_speed * 1.5, room_speed * 3);
}

ring_angle += rotation_speed * rotation_dir;

if (shoot_timer <= 0)
{
    var bullet_count = 12;
    var speed_base = 1.5;

    for (var i = 0; i < bullet_count; i++)
    {
        var dir = ring_angle + (360 / bullet_count) * i;

        var b = instance_create_layer(center_x, center_y, "Instances", oBossBullet);
        b.sprite_index = sShootingStar;
        b.dir_value = dir;
        b.speed_value = speed_base;
    }

    shoot_timer = shoot_delay;
}