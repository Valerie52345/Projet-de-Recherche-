//Retour au même combat en appuyant sur Z 
if (keyboard_check_pressed(ord("Z")))
{
        room_goto(rm_RPG);
	audio_stop_all();

}

if (!audio_is_playing(snd_gameover_theme))
{
audio_play_sound(snd_gameover_theme, 1, true);
}