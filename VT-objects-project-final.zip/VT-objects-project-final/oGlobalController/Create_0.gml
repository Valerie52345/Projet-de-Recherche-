// Attribuer le booléen + la musique
global.timee_defeated = false;
audio_play_sound(snd_rpg_theme, 1, true);